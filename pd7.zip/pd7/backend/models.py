from django.db import models

# Create your models here.

class UserInfo(models.Model):
	username=models.CharField(max_length=20)
	firstname=models.CharField(max_length=20)
	middlename=models.CharField(max_length=20)
	lastname=models.CharField(max_length=20)
	email=models.CharField(max_length=20)
	addr1=models.CharField(max_length=40)
	addr2=models.CharField(max_length=40)
	city=models.CharField(max_length=10)
	state=models.CharField(max_length=20)
	zipcode=models.CharField(max_length=10)
	empName=models.CharField(max_length=20)

class Subscriber(models.Model):
 subscriberID=models.CharField(max_length=20)
 username=models.ForeignKey(UserInfo,on_delete=models.CASCADE)
 subTypeCode=models.CharField(max_length=5)
 servicecode=models.CharField(max_length=5)
 requestDate=models.DateTimeField(max_length=10)
 startDate=models.DateTimeField(max_length=10)
 endDate=models.DateTimeField(max_length=10)
 motifOfcancellation=models.CharField(max_length=20)
 beneficiaryID=models.CharField(max_length=10)

class transferredSub(models.Model):
	transferFrom=models.CharField(max_length=20)
	transferTo=models.CharField(max_length=20)
	requestDate=models.DateTimeField(max_length=10)
	transferDate=models.DateTimeField(max_length=10)
	subscriberID=models.ForeignKey(Subscriber,on_delete=models.CASCADE)

class SubscriptionType(models.Model):
 	subTypeCode=models.ForeignKey(Subscriber,on_delete=models.CASCADE)
 	subTypeName=models.CharField(max_length=20)

class Service(models.Model):
 	servicecode=models.ForeignKey(Subscriber,on_delete=models.CASCADE)
 	servicename=models.CharField(max_length=20)
 	description=models.CharField(max_length=20)
 	premium=models.CharField(max_length=20)
 	allocation=models.CharField(max_length=20)

class office(models.Model):
	name = models.CharField(max_length=20,default='default')
	officeCode=models.CharField(max_length=4)
	attribution=models.CharField(max_length=10)
	def _str_(self):
	 return self.name

class officer(models.Model):
	subscriberID=models.ForeignKey(Subscriber,on_delete=models.CASCADE)
	officeCode=models.ForeignKey(office,on_delete=models.CASCADE)
	startDate=models.CharField(max_length=10)
	endDate=models.CharField(max_length=10)

class organization(models.Model):
	orgCe=models.CharField(max_length=5)
	orgName=models.CharField(max_length=10)
	datejoined=models.DateTimeField()
	address=models.CharField(max_length=30)
	city=models.CharField(max_length=10)
	state=models.CharField(max_length=10)
	phone=models.CharField(max_length=10)

class organizationMem(models.Model):
	orgCode=models.ForeignKey(organization,on_delete=models.CASCADE)
	subscriberID=models.ForeignKey(Subscriber,on_delete=models.CASCADE)
	memStrtDate=models.DateTimeField(max_length=10)
	memEndDate=models.DateTimeField(max_length=10)
	nativeCountry=models.CharField(max_length=10)
	citizenship=models.CharField(max_length=10)
	isDelegate=models.BooleanField()